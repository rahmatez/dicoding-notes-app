import { getAllStories, getStoryDetail, addStory } from "../../data/api";

class StoryModel {
  constructor() {
    this._stories = [];
    this._currentPage = 1;
    this._hasMoreStories = true;
  }

  async getStories(page = 1, size = 10, withLocation = false) {
    try {
      const data = await getAllStories({
        page: page,
        size: size,
        location: withLocation ? 1 : 0,
      });

      const { listStory } = data;
      this._hasMoreStories = listStory.length > 0;

      if (page === 1) {
        this._stories = listStory;
      } else {
        this._stories = [...this._stories, ...listStory];
      }

      this._currentPage = page + 1;
      return listStory;
    } catch (error) {
      throw new Error(error.message || "Gagal memuat cerita");
    }
  }

  async getStoryDetail(id) {
    try {
      if (!id) {
        throw new Error("ID cerita tidak valid");
      }

      console.log("Fetching story detail for ID:", id);
      const response = await getStoryDetail(id);

      if (!response || !response.story) {
        console.error("Invalid story detail response:", response);
        throw new Error("Data cerita tidak ditemukan");
      }

      return response.story;
    } catch (error) {
      console.error("Error in model.getStoryDetail:", error);
      throw new Error(error.message || "Gagal memuat detail cerita");
    }
  }

  async addStory(formData) {
    try {
      const response = await addStory(formData);
      return response;
    } catch (error) {
      throw new Error(error.message || "Gagal menambahkan cerita");
    }
  }

  get currentPage() {
    return this._currentPage;
  }

  get hasMoreStories() {
    return this._hasMoreStories;
  }

  get stories() {
    return [...this._stories];
  }

  resetState() {
    this._stories = [];
    this._currentPage = 1;
    this._hasMoreStories = true;
  }
}

export default StoryModel;
