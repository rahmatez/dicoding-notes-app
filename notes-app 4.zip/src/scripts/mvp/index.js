// Models
import StoryModel from "./models/story-model";

// Views
import HomeView from "./views/home-view";

// Presenters
import HomePresenter from "./presenters/home-presenter";

// Create instances
const storyModel = new StoryModel();

// Export functions to initialize MVP components
export const initHomePageMVP = () => {
  const view = new HomeView();
  const presenter = new HomePresenter({
    view,
    model: storyModel,
  });

  return {
    view,
    presenter,
    render: () => view.getTemplate(),
    afterRender: async () => {
      await presenter.init();
    },
  };
};

// Export model instances for reuse
export const models = {
  story: storyModel,
};
