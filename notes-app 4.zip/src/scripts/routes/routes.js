// Import lama untuk halaman yang belum di-refactor
import AboutPage from "../pages/about/about-page";
import DetailPage from "../pages/detail/detail-page";
import CreateStoryPage from "../pages/create/create-story-page";
import MapPage from "../pages/map/map-page";
import LoginPage from "../pages/auth/login-page";
import RegisterPage from "../pages/auth/register-page";
import { checkAuth } from "../utils";

// Import untuk MVP pattern (Model-View-Presenter)
// Pendekatan MVP memisahkan kode menjadi 3 bagian:
// - Model: Menangani data dan logika bisnis
// - View: Menangani tampilan dan UI
// - Presenter: Penghubung antara Model dan View
import { initHomePageMVP } from "../mvp/index";

// Initialize MVP for home page
// Ini menggantikan pendekatan lama dengan implementasi MVP yang lebih terstruktur
const homeMVP = initHomePageMVP();

const routes = {
  "/": homeMVP, // Using MVP pattern for homepage
  "/about": new AboutPage(),
  "/detail/:id": new DetailPage(),
  "/create": new CreateStoryPage(),
  "/map": new MapPage(),
  "/login": new LoginPage(),
  "/register": new RegisterPage(),
};

export default routes;
