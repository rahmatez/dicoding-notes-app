import { getAllStories, getGuestStories } from "../../data/api";
import { checkAuth, showFormattedDateTime } from "../../utils";

class HomePage {
  constructor() {
    this._stories = [];
    this._currentPage = 1;
    this._hasMoreStories = true;
    this._isLoading = false;
    this._storiesLoaded = false; // Untuk melacak apakah cerita sudah dimuat
  }

  async render() {
    return `
      <section class="container">
        <div class="home-header">
          <h1>Cerita Terbaru</h1>
          <p>Jelajahi berbagai cerita menarik dari komunitas Dicoding</p>
        </div>

        <div id="stories-container" class="stories-grid"></div>
        
        <div id="loading" class="loading hidden">
          <div class="spinner"></div>
          <p>Memuat cerita...</p>
        </div>

        <div id="error-container" class="alert alert-error hidden"></div>

        ${
          !checkAuth()
            ? `
         
        `
            : `
        `
        }
      </section>
    `;
  }

  async afterRender() {
    this._storiesContainer = document.getElementById("stories-container");
    this._loadingElement = document.getElementById("loading");
    this._errorContainer = document.getElementById("error-container");

    // Clear the container before fetching stories to prevent duplication
    if (this._storiesContainer) {
      this._storiesContainer.innerHTML = "";
    }

    // Reset error container if it exists
    if (this._errorContainer) {
      this._errorContainer.classList.add("hidden");
    }

    await this._fetchStories();

    // Infinite scroll
    window.addEventListener("scroll", () => {
      const { scrollTop, scrollHeight, clientHeight } =
        document.documentElement;
      if (
        scrollTop + clientHeight >= scrollHeight - 10 &&
        !this._isLoading &&
        this._hasMoreStories
      ) {
        this._fetchStories();
      }
    });

    // Menerapkan View Transition API dan memastikan semua link berfungsi
    document.documentElement.addEventListener("click", (event) => {
      const target = event.target.closest("a");
      if (target && target.href && target.href.includes("#/")) {
        // Log untuk debugging
        console.log(
          "Link clicked in home-page:",
          target.href,
          target.className
        );

        if (document.startViewTransition) {
          event.preventDefault();
          document.startViewTransition(() => {
            window.location.href = target.href;
          });
        }
      }
    });
  }

  async _fetchStories() {
    try {
      this._isLoading = true;
      this._showLoading();

      // Periksa status autentikasi
      if (checkAuth()) {
        // Jika user sudah login, gunakan API biasa
        const data = await getAllStories({
          page: this._currentPage,
          size: 10,
          location: 1,
        });

        const { listStory } = data;

        if (listStory.length === 0) {
          this._hasMoreStories = false;
        } else {
          this._stories = [...this._stories, ...listStory];
          this._currentPage += 1;
          this._renderStories();
        }
      } else {
        try {
          // Coba gunakan API guest jika tersedia
          const guestData = await getGuestStories();
          const { listStory } = guestData;

          if (listStory && listStory.length > 0) {
            this._stories = listStory;
            this._hasMoreStories = false; // Tidak ada infinite scroll untuk guest
            this._renderStories();
          } else {
            this._showWelcomeMessage();
          }
        } catch (guestError) {
          console.log("Guest stories not available:", guestError);
          this._showWelcomeMessage();
        }
      }

      this._hideLoading();
      this._isLoading = false;
    } catch (error) {
      this._hideLoading();
      this._isLoading = false;

      if (!checkAuth()) {
        // Jika belum login dan error, tampilkan pesan sambutan
        this._showWelcomeMessage();
      } else {
        this._showError(error.message || "Gagal memuat cerita");
      }
    }
  }

  _showWelcomeMessage() {
    this._storiesContainer.innerHTML = `
      <div class="welcome-message">
        <h2>Selamat Datang di Dicoding Story</h2>
        <p>Silahkan <a href="#/login">Masuk</a> untuk melihat cerita dari komunitas Dicoding.</p>
        <p>Belum punya akun? <a href="#/register">Daftar</a> sekarang!</p>
      </div>
    `;
  }

  _renderStories() {
    // Mark that we have stories loaded
    this._storiesLoaded = true;

    // Check if there are any duplicate stories already rendered
    const existingStoryIds = Array.from(
      this._storiesContainer.querySelectorAll(".story-card")
    ).map((card) => card.id.replace("story-", ""));

    // Only render stories that aren't already displayed
    this._stories.forEach((story) => {
      if (!existingStoryIds.includes(story.id)) {
        const storyElement = this._createStoryCard(story);
        this._storiesContainer.appendChild(storyElement);
      }
    });
  }

  _createStoryCard(story) {
    const storyCard = document.createElement("article");
    storyCard.classList.add("card", "story-card");
    storyCard.setAttribute("id", `story-${story.id}`);

    const mapLink =
      story.lat && story.lon
        ? `<a href="#/map?lat=${story.lat}&lon=${story.lon}" class="story-card__map-link" title="Lihat lokasi di peta">
           <i class="fas fa-map-marker-alt"></i> Lihat Lokasi
         </a>`
        : "";

    storyCard.innerHTML = `
      <img 
        src="${story.photoUrl}" 
        alt="Foto dari ${story.name}"
        class="story-card__image"
      >
      <div class="story-card__content">
        <h2 class="story-card__title">
          <a href="#/detail/${story.id}">${story.name}</a>
        </h2>
        <div class="story-card__meta">
          <span><i class="fas fa-calendar"></i> ${showFormattedDateTime(
            story.createdAt
          )}</span>
          ${mapLink}
        </div>
        <p class="story-card__description">${story.description}</p>
        <a href="#/detail/${
          story.id
        }" class="btn story-card__read-more">Baca selengkapnya</a>
      </div>
    `;

    return storyCard;
  }

  _showLoading() {
    this._loadingElement.classList.remove("hidden");
  }

  _hideLoading() {
    this._loadingElement.classList.add("hidden");
  }

  _showError(message) {
    // Jika error berkaitan dengan authentication untuk user yang belum login,
    // tampilkan pesan selamat datang sebagai gantinya
    if (
      !checkAuth() &&
      (message.includes("authentication") ||
        message.includes("token") ||
        message.includes("Missing authentication"))
    ) {
      this._showWelcomeMessage();
      return;
    }

    this._errorContainer.textContent = message;
    this._errorContainer.classList.remove("hidden");
  }
}

export default HomePage;
