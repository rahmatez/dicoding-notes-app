import HomePage from "../pages/home/home-page";
import AboutPage from "../pages/about/about-page";
import DetailPage from "../pages/detail/detail-page";
import CreateStoryPage from "../pages/create/create-story-page";
import MapPage from "../pages/map/map-page";
import LoginPage from "../pages/auth/login-page";
import RegisterPage from "../pages/auth/register-page";
import { checkAuth } from "../utils";

// Buat instance HomePage yang akan digunakan untuk semua navigasi ke beranda
// Ini akan memastikan data cerita tetap ada saat pengguna navigasi ke beranda berulang kali
const homePageInstance = new HomePage();

const routes = {
  "/": homePageInstance,
  "/about": new AboutPage(),
  "/detail/:id": new DetailPage(),
  "/create": new CreateStoryPage(),
  "/map": new MapPage(),
  "/login": new LoginPage(),
  "/register": new RegisterPage(),
};

export default routes;
